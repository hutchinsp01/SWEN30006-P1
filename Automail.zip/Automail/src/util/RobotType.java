/**
 * Created by Paul Hutchins - 1160468, Jade Siang - 1170856, Kian Dsouza - 1142463
 * in conjunction with the brief stated by the SWEN3006 assignment 1
 */

package util;

/**
 * Enum to store all robot types
 */
public enum RobotType {
	REG, BULK, FAST;
}
